fx_version 'cerulean'
game 'gta5'
version '1.0.1'
description 'nafing Hud DC: ✪ dydolek#2137'

ui_page 'html/ui.html'

client_scripts {
	'client.lua'
}

files {
	'html/ui.html',
	'html/style.css',
	'html/main.js',
	'html/img/*.png',
}
